import { useNavigate, useParams } from "react-router-dom";
import PostForm from "../components/PostForm";
import { useUpdatePostMutation } from "../services/Mutations";
import { Todo } from "../types/todo";
import { useGetTodosQueryById } from "../services/Queries";

const EditPost = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const {
    isLoading,
    isError,
    data: post,
    error,
  } = useGetTodosQueryById(id as string);

  const updatePostMutation = useUpdatePostMutation(); 

  const handleSubmit = (updatedPost: Todo) => {
    console.log(updatedPost);
    updatePostMutation.mutate({ id, ...updatedPost });
    navigate("/");
  };

  const initialValue = post || { id: "", title: "", body: "" };

  if (isLoading) return <div>Loading...</div>;
  if (isError) return <div>Error: {error?.message}</div>;

  return (
    <div>
      <PostForm onSubmit={handleSubmit} initialValue={initialValue} />
    </div>
  );
};

export default EditPost;
