import { useNavigate, useParams } from "react-router-dom";
import { useGetTodosQueryById } from "../services/Queries";
import "./posts.css";

const Post = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const {
    isLoading,
    isError,
    data: post,
    error,
  } = useGetTodosQueryById(id as string);

  if (isLoading) return <div>loading...</div>;
  if (isError) return <div>Error: {error?.message}</div>;

  return (
    <div className="cards">
      <p className="title">{post?.title}</p>
      <p>{post?.body}</p>
      <p>
        {" "}
        <button className="btns" onClick={() => navigate("/")}>back to list posts</button>
      </p>
    </div>
  );
};

export default Post;
