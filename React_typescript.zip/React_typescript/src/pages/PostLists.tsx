import { useNavigate } from "react-router-dom";
import AddPost from "../components/AddPost";
import { useGetTodosQuery } from "../services/Queries";
import { useDeletePostMutation } from "../services/Mutations";
import "./post.css";

const PostLists = () => {
  const navigate = useNavigate();

  const { isLoading, isError, data: posts, error } = useGetTodosQuery();

  const deletePostMutation = useDeletePostMutation();

  const handleDelete = (id: string) => {
    deletePostMutation.mutate(id);
  };

  if (isLoading) return <div>loading...</div>;
  if (isError) return <div>Error: {error?.message}</div>;

  return (
    <>
      <AddPost />
      <br />
      < div className="box">
      {posts?.map((post) => (
        <div className="card" key={post.id}>
          <div className="containers">
            <h4
              style={{ cursor: "pointer" }}
              onClick={() => navigate(`/post/${post.id}`)}
            >
              <b> {post.title}</b>
            </h4>
            <button className="button button2" onClick={() => navigate(`/post/${post.id}/edit`)}>
              Edit
            </button>
            <button className="button button3" onClick={() => handleDelete(post.id ?? "")}>Delete</button>
          </div>
        </div>
        
      ))}
      </div>
    </>
  );
};

export default PostLists;
