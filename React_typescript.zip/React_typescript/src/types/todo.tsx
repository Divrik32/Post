export interface Todo {
    id?: string;
    title: string;
    body: string;
  }

  export interface PostFormProps {
    onSubmit: (post: Todo) => void;
    initialValue: { title: string; body: string };
  }