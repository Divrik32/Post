import { useQuery, UseQueryResult } from "@tanstack/react-query";
import { Todo } from "../types/todo";
import { fetchPosts, fetchPost } from "../api/post";

export const useGetTodosQuery = (): UseQueryResult<Todo[], Error> => {
  return useQuery<Todo[], Error>({
    queryKey: ["posts"],
    queryFn: fetchPosts,
  });
};

export const useGetTodosQueryById = (id: string): UseQueryResult<Todo, Error> => {
  return useQuery<Todo, Error>({
    queryKey: ["posts", id],
    queryFn: () => fetchPost(id),
  });
};
