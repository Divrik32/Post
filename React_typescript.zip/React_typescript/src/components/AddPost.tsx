import PostForm from "./PostForm";
import { v4 as uuidv4 } from "uuid";
import { useCreatePostMutation } from "../services/Mutations";
import "./form.css";

const AddPost = () => {
  const createPostMutation = useCreatePostMutation();

  const handleAddPost = (post: { title: string; body: string }) => {
    const newPost = {
      id: uuidv4(),
      ...post,
    };
    createPostMutation.mutate(newPost);
  };

  return (
    <div>
      <h2 style={{textAlign:"center"}}>Add new post</h2>
      <PostForm
        onSubmit={handleAddPost}
        initialValue={{ title: "", body: "" }}
      />
    </div>
  );
};

export default AddPost;
