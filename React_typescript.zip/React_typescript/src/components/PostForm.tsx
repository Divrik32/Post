import React from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { PostFormProps, Todo } from "../types/todo";

const schema = yup.object().shape({
  title: yup.string().required("Title is required"),
  body: yup.string().required("Content is required"),
});

const PostForm: React.FC<PostFormProps> = ({ onSubmit, initialValue }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<Todo>({
    resolver: yupResolver(schema),
    defaultValues: initialValue,
  });

  const onSubmitForm = handleSubmit((data) => {
    onSubmit(data);
    reset();
  });

  return (
    <div className="container">
      <form onSubmit={onSubmitForm}>
        <div className="row">
          <div className="col-25">
            <label htmlFor="title">Title</label>
          </div>
          <div className="col-75">
            <input {...register("title")} type="text" id="title" />
            {errors.title && <p>{errors.title.message}</p>}
          </div>
        </div>
        <div className="row">
          <div className="col-25">
            <label htmlFor="body">Content</label>
          </div>
          <div className="col-75">
            <textarea
              {...register("body")}
              id="body"
              placeholder="Write something.."
            />
            {errors.body && <p>{errors.body.message}</p>}
          </div>
        </div>
        <br />
        <div className="row">
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
};

export default PostForm;
