import { Todo } from "../types/todo";
import axios, { AxiosInstance } from "axios";

const BASE_URL = "http://localhost:3000/posts";

const axiosInstance: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export const fetchPosts = async (): Promise<Todo[]> => {
  const response = await axiosInstance.get<Todo[]>("");
  return response.data;
};

export const fetchPost = async (id: string): Promise<Todo> => {
  const response = await axiosInstance.get<Todo>(`${id}`);
  return response.data;
};

export const createPost = async (newPost: {
  title: string;
  body: string;
}): Promise<Todo> => {
  const response = await axiosInstance.post<Todo>("", newPost);
  return response.data;
};

export const updatePost = async (updatedPost: Todo): Promise<Todo> => {
  const response = await axiosInstance.put<Todo>(
    `${updatedPost.id}`,
    updatedPost
  );
  return response.data; 
};

export const deletePost = async (id: string): Promise<void> => {
  await axiosInstance.delete(`${id}`);
};
