import React from 'react';
import { useQuery } from 'react-query';
import { useParams } from 'react-router-dom';
import { fetchPostById } from '../api/posts';
import { Container, Paper, Typography, Button, CircularProgress } from '@mui/material';
import 'bootstrap/dist/css/bootstrap.min.css';

const PostDetails = () => {
  const { id } = useParams();
  const { data: post, isLoading, isError } = useQuery(['post', id], () => fetchPostById(id));

  if (isLoading) return <CircularProgress style={{ display: 'block', margin: 'auto' }} />;
  if (isError) return <Typography color="error" align="center">Error fetching post</Typography>;

  return (
    <Container maxWidth="sm" style={{ marginTop: '20px' }}>
      <Paper elevation={3} style={{ padding: '20px', backgroundColor: '#f0f4ff', borderRadius: '10px' }}>
        <Typography variant="h4" component="h2" gutterBottom style={{ color: '#3f51b5' }}>
          {post.title}
        </Typography>
        <Typography variant="body1" style={{ color: '#333', lineHeight: '1.6' }}>
          {post.body}
        </Typography>
        <div style={{ marginTop: '20px', textAlign: 'right' }}>
          <Button variant="contained" color="primary" onClick={() => window.history.back()} style={{ backgroundColor: '#ff4081' }}>
            Back
          </Button>
        </div>
      </Paper>
    </Container>
  );
};

export default PostDetails;
