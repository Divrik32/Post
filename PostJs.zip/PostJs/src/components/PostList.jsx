import React from 'react';
import { useQuery, useMutation, useQueryClient } from 'react-query';
import { fetchPosts, deletePost } from '../api/posts';
import { Link } from 'react-router-dom';
import styles from './PostList.module.css';

const PostList = () => {
  const queryClient = useQueryClient();
  
  const { data: posts = [], isLoading, isError } = useQuery('posts', fetchPosts);

  const mutation = useMutation(deletePost, {
    onSuccess: () => {
      // Invalidate and refetch the posts after a successful delete
      queryClient.invalidateQueries('posts');
    }
  });

  const handleDelete = (postId) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      mutation.mutate(postId);
    }
  };

  if (isLoading) return <div>Loading...</div>;
  if (isError) return <div>Error fetching posts</div>;

  return (
    <div className={styles.postList}>
      {posts.map((post) => (
        <div key={post.id} className={styles.card}>
          <h3 className={styles.postTitle}>{post.title}</h3>
          <p className={styles.postBody}>{post.body}</p>
          <div className={styles.buttonGroup}>
            <Link to={`/edit/${post.id}`} className={styles.editButton}>Edit</Link>
            <Link to={`/post/${post.id}`} className={styles.viewButton}>View</Link>
            <button 
              onClick={() => handleDelete(post.id)} 
              className={styles.deleteButton}
            >
              Delete
            </button>
          </div>
        </div>
      ))}
      <Link to="/add" className={styles.addPostButton}>Add New Post</Link>
    </div>
  );
};

export default PostList;
