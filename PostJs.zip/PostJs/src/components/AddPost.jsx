import React, { useState } from 'react';
import { useMutation, useQueryClient } from 'react-query';
import { createPost } from '../api/posts';
import { useNavigate } from 'react-router-dom';
import styles from './PostForm.module.css';

const AddPost = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  const mutation = useMutation(createPost, {
    onSuccess: () => {
      queryClient.invalidateQueries('posts');
      navigate('/');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate({ title, body });
    setTitle('');
    setBody('');
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <h2 className={styles.title}>Create a New Post</h2>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        required
        className={styles.input}
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Body"
        required
        className={styles.textarea}
      />
      <button type="submit" className={styles.button}>Add Post</button>
    </form>
  );
};

export default AddPost;
