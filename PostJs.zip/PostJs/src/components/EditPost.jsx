import React, { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from 'react-query';
import { useParams, useNavigate } from 'react-router-dom';
import styles from './PostForm.module.css';
import { fetchPosts, updatePost } from '../api/posts';

const EditPost = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { id } = useParams();
  
  const { data: post, isLoading, isError } = useQuery(['post', id], () => fetchPosts(id));
  const mutation = useMutation(updatePost, {
    onSuccess: () => {
      queryClient.invalidateQueries('posts');
      navigate('/');
    },
  });

  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');

  useEffect(() => {
    if (post) {
      setTitle(post.title);
      setBody(post.body);
    }
  }, [post]);

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate({ id, post: { title, body } });
  };

  if (isLoading) return <div>Loading...</div>;
  if (isError) return <div>Error fetching post</div>;

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <h2 className={styles.title}>Edit Post</h2>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Title"
        required
        className={styles.input}
      />
      <textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Body"
        required
        className={styles.textarea}
      />
      <button type="submit" className={styles.button1}>Update Post</button>
    </form>
  );
};

export default EditPost;
